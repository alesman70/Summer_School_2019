# index.R - DESC
# index.R

# Copyright 2003-2014 FLR Team. Distributed under the GPL 2 or later
# Maintainer: Iago Mosqueira, JRC
# Soundtrack:
# Notes:

sd_section("ggplot",
  "Overloaded ggplot method for various FLR classes",
  c("ggplot,FLQuant-method"))

sd_section("FLR classes plot",
  "ggplot-based plot for different FLR classes",
  c("plot,FLQuants,missing-method"))

